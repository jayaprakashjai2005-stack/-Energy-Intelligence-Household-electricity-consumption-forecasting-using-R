# =====================================================================
# Energy Intelligence Dashboard  (R + Shiny)
# Run:  shiny::runApp()   (from the project folder)
# =====================================================================
library(shiny); library(shinydashboard); library(dplyr); library(ggplot2); library(DT)
source("R/energy_functions.R")

DEFAULT_CSV <- "data/energy_data.csv"
DAYS <- c("Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun")
fmt <- function(x) format(round(x), big.mark = ",")

ui <- dashboardPage(
  skin = "green",
  dashboardHeader(title = "Energy Intelligence"),
  dashboardSidebar(
    sidebarMenu(
      menuItem("Overview",             tabName = "overview", icon = icon("bolt")),
      menuItem("Consumption Patterns", tabName = "patterns", icon = icon("chart-line")),
      menuItem("Anomaly Detection",    tabName = "anomaly",  icon = icon("exclamation-triangle")),
      menuItem("ML Forecasting",       tabName = "ml",       icon = icon("cogs")),
      menuItem("Savings Simulator",    tabName = "savings",  icon = icon("leaf")),
      menuItem("Data",                 tabName = "data",     icon = icon("table"))),
    hr(),
    fileInput("file", "Upload CSV (optional)", accept = ".csv"),
    helpText(style = "color:#b8c7ce; padding:0 15px;", "Needs Timestamp + Energy_kWh. Extra columns (Temperature_C, Humidity_pct, Occupancy_pct...) improve the model."),
    numericInput("tariff", "Tariff (Rs/kWh)", 8, min = 0, step = 0.5),
    numericInput("ef", "Emission factor (kg CO2/kWh)", 0.82, min = 0, step = 0.01),
    uiOutput("date_ui")),
  dashboardBody(tabItems(
    tabItem("overview",
      fluidRow(valueBoxOutput("vb_kwh", 3), valueBoxOutput("vb_peak", 3),
               valueBoxOutput("vb_cost", 3), valueBoxOutput("vb_co2", 3)),
      fluidRow(box(title = "Daily consumption", width = 8, status = "success", plotOutput("p_daily", height = 300)),
               box(title = "Data quality log", width = 4, status = "info", tableOutput("t_log")))),
    tabItem("patterns",
      fluidRow(box(width = 12, status = "success", title = "Consumption over time",
                   radioButtons("gran", NULL, c("Hourly", "Daily", "Weekly"), "Daily", inline = TRUE),
                   plotOutput("p_ts", height = 280))),
      fluidRow(box(width = 6, title = "Average load: hour x weekday", plotOutput("p_heat", height = 300)),
               box(width = 6, title = "Temperature vs energy", plotOutput("p_temp", height = 300))),
      fluidRow(box(width = 12, title = "Monthly consumption", plotOutput("p_month", height = 250)))),
    tabItem("anomaly",
      fluidRow(box(width = 4, title = "Settings", status = "warning",
                   sliderInput("k", "Sensitivity (robust z-score threshold)", 2, 10, 4, 0.5),
                   helpText("Expected load = Random Forest (out-of-bag) prediction from weather, occupancy and time. Lower threshold = more alerts."),
                   valueBoxOutput("vb_an", 12), valueBoxOutput("vb_excess", 12)),
               box(width = 8, title = "Detected anomalies", status = "danger", plotOutput("p_an", height = 360))),
      fluidRow(box(width = 12, title = "Top anomalous hours", DTOutput("t_an")))),
    tabItem("ml",
      fluidRow(box(width = 3, title = "Train models", status = "primary",
                   sliderInput("split", "Training share (chronological)", 0.6, 0.9, 0.8, 0.05),
                   sliderInput("trees", "Random Forest trees", 50, 500, 200, 50),
                   actionButton("train", "Train & evaluate", icon = icon("play"), class = "btn-success"),
                   hr(), radioButtons("pm", "Show predictions of", c("Random Forest" = "rf", "Decision Tree" = "dt", "Linear Regression" = "lm"))),
               box(width = 9, title = "Model comparison (test set)", tableOutput("t_metrics"),
                   plotOutput("p_ap", height = 300))),
      fluidRow(box(width = 6, title = "First week of test period: actual vs forecast", plotOutput("p_week", height = 280)),
               box(width = 6, title = "Random Forest feature importance", plotOutput("p_imp", height = 280))),
      fluidRow(box(width = 12, title = "What-if: predict load for a scenario (Random Forest)", status = "info",
                   column(2, numericInput("w_temp", "Temperature (C)", 32)),
                   column(2, numericInput("w_hum", "Humidity (%)", 70)),
                   column(2, numericInput("w_occ", "Occupancy (%)", 80)),
                   column(2, numericInput("w_hour", "Hour (0-23)", 14, 0, 23)),
                   column(2, checkboxInput("w_wend", "Weekend", FALSE)),
                   column(2, h4(textOutput("whatif")))))),
    tabItem("savings",
      fluidRow(box(width = 4, title = "Efficiency scenario", status = "success",
                   sliderInput("s_peak", "Reduce weekday peak load (11-17h) by %", 0, 30, 10),
                   sliderInput("s_low", "Reduce low-occupancy load (<20%) by %", 0, 40, 15),
                   helpText("Example actions: raise AC set-point, shift loads, switch off idle equipment.")),
               valueBoxOutput("vb_s_kwh", 3), valueBoxOutput("vb_s_cost", 3), valueBoxOutput("vb_s_co2", 2)),
      fluidRow(box(width = 12, title = "Monthly consumption: baseline vs scenario", plotOutput("p_save", height = 300)))),
    tabItem("data",
      fluidRow(box(width = 12, downloadButton("dl", "Download cleaned data (CSV)"), br(), br(), DTOutput("t_data"))))
  ))
)

server <- function(input, output, session) {
  # ---- data ----------------------------------------------------------
  loaded <- reactive({
    path <- if (is.null(input$file)) DEFAULT_CSV else input$file$datapath
    tryCatch(load_energy_data(path), error = function(e) {
      showNotification(paste("Upload problem:", conditionMessage(e), "- showing default data."), type = "error", duration = 8)
      load_energy_data(DEFAULT_CSV)
    })
  })
  all_df <- reactive(add_features(loaded()$data))
  output$date_ui <- renderUI({
    d <- all_df()$Date
    dateRangeInput("dates", "Date range", start = min(d), end = max(d), min = min(d), max = max(d))
  })
  df <- reactive({ req(input$dates); all_df() %>% filter(Date >= input$dates[1], Date <= input$dates[2]) })
  tariff <- reactive(input$tariff); ef <- reactive(input$ef)

  # ---- overview ------------------------------------------------------
  output$vb_kwh  <- renderValueBox(valueBox(paste(fmt(sum(df()$Energy_kWh) / 1000), "MWh"), "Total consumption", icon = icon("bolt"), color = "green"))
  output$vb_peak <- renderValueBox(valueBox(paste(round(max(df()$Energy_kWh)), "kWh"), "Peak hourly demand", icon = icon("arrow-up"), color = "orange"))
  output$vb_cost <- renderValueBox(valueBox(paste("Rs", fmt(sum(df()$Energy_kWh) * tariff() / 1e5), "lakh"), "Estimated cost", icon = icon("rupee-sign"), color = "blue"))
  output$vb_co2  <- renderValueBox(valueBox(paste(fmt(sum(df()$Energy_kWh) * ef() / 1000), "t"), "CO2 emissions", icon = icon("cloud"), color = "red"))
  daily <- reactive(df() %>% group_by(Date) %>% summarise(kWh = sum(Energy_kWh), .groups = "drop"))
  output$p_daily <- renderPlot(ggplot(daily(), aes(Date, kWh)) + geom_line(colour = "#264653") +
    geom_smooth(se = FALSE, colour = "#e76f51", method = "loess", formula = y ~ x) + theme_minimal(base_size = 13) + labs(y = "kWh / day"))
  output$t_log <- renderTable({
    l <- loaded()$log
    data.frame(Check = c("Raw rows", "Unparseable timestamps", "Duplicate rows removed", "Missing values filled", "Clean rows"),
               Value = c(l$rows_raw, l$bad_timestamps, l$duplicates, l$missing_filled, l$rows_clean))
  })

  # ---- patterns ------------------------------------------------------
  output$p_ts <- renderPlot({
    d <- df()
    d$grp <- switch(input$gran, Hourly = d$Timestamp, Daily = as.POSIXct(d$Date), Weekly = as.POSIXct(as.Date(cut(d$Date, "week"))))
    a <- d %>% group_by(grp) %>% summarise(kWh = if (input$gran == "Hourly") mean(Energy_kWh) else sum(Energy_kWh), .groups = "drop")
    ggplot(a, aes(grp, kWh)) + geom_line(colour = "#2a9d8f") + theme_minimal(base_size = 13) + labs(x = NULL, y = "kWh")
  })
  output$p_heat <- renderPlot({
    h <- df() %>% group_by(Weekday, Hour) %>% summarise(kWh = mean(Energy_kWh), .groups = "drop")
    ggplot(h, aes(Hour, factor(Weekday, 1:7, DAYS), fill = kWh)) + geom_tile() + scale_fill_viridis_c(option = "magma") +
      theme_minimal(base_size = 13) + labs(y = NULL)
  })
  output$p_temp <- renderPlot({
    validate(need("Temperature_C" %in% names(df()), "No Temperature_C column in data."))
    ggplot(df(), aes(Temperature_C, Energy_kWh)) + geom_point(alpha = 0.15, colour = "#457b9d") +
      geom_smooth(colour = "#e63946", method = "gam", formula = y ~ s(x, bs = "cs")) + theme_minimal(base_size = 13)
  })
  output$p_month <- renderPlot({
    m <- df() %>% group_by(Month) %>% summarise(kWh = sum(Energy_kWh), .groups = "drop")
    ggplot(m, aes(factor(Month), kWh)) + geom_col(fill = "#f4a261") + theme_minimal(base_size = 13) + labs(x = "Month")
  })

  # ---- anomalies -----------------------------------------------------
  expected <- reactive({ withProgress(message = "Learning expected load...", fit_expected(all_df())) })
  an <- reactive({ req(input$dates); a <- flag_anomalies(expected(), input$k); a %>% filter(Date >= input$dates[1], Date <= input$dates[2]) })
  output$vb_an     <- renderValueBox(valueBox(sum(an()$Anomaly), "Anomalous hours", icon = icon("exclamation-triangle"), color = "red"))
  output$vb_excess <- renderValueBox({ x <- sum(an()$Resid[an()$Anomaly]); valueBox(paste(fmt(x), "kWh"), paste("Excess energy (Rs", fmt(x * tariff()), ")"), icon = icon("fire"), color = "yellow") })
  output$p_an <- renderPlot(ggplot(an(), aes(Timestamp, Energy_kWh)) + geom_line(colour = "grey70", linewidth = 0.25) +
    geom_point(data = filter(an(), Anomaly), colour = "red", size = 2) + theme_minimal(base_size = 13) + labs(y = "kWh"))
  output$t_an <- renderDT({
    t <- an() %>% filter(Anomaly) %>% arrange(desc(Z)) %>% transmute(Timestamp = format(Timestamp), Actual_kWh = Energy_kWh,
           Expected_kWh = round(Expected, 1), Excess_kWh = round(Resid, 1), Z_score = round(Z, 1))
    datatable(t, options = list(pageLength = 8), rownames = FALSE)
  })

  # ---- ML ------------------------------------------------------------
  fit <- eventReactive(input$train, {
    withProgress(message = "Training Linear Regression, Decision Tree, Random Forest...", {
      sp <- split_time(all_df(), input$split)
      list(sp = sp, models = train_models(sp$train, get_predictors(all_df()), input$trees))
    })
  }, ignoreNULL = FALSE)
  output$t_metrics <- renderTable(evaluate_all(fit()$models, fit()$sp$test), digits = 4)
  output$p_ap <- renderPlot({
    f <- fit(); d <- data.frame(Actual = f$sp$test$Energy_kWh, Predicted = predict_model(f$models, input$pm, f$sp$test))
    ggplot(d, aes(Actual, Predicted)) + geom_point(alpha = 0.25, colour = "#1d3557") + geom_abline(colour = "red") + theme_minimal(base_size = 13)
  })
  output$p_week <- renderPlot({
    f <- fit(); wk <- head(f$sp$test, 24 * 7); wk$Forecast <- predict_model(f$models, input$pm, wk)
    ggplot(wk, aes(Timestamp)) + geom_line(aes(y = Energy_kWh, colour = "Actual")) + geom_line(aes(y = Forecast, colour = "Forecast")) +
      scale_colour_manual(values = c(Actual = "#264653", Forecast = "#e76f51")) + theme_minimal(base_size = 13) + labs(y = "kWh", colour = NULL)
  })
  output$p_imp <- renderPlot({
    v <- fit()$models$rf$variable.importance; d <- data.frame(Feature = names(v), Importance = as.numeric(v))
    ggplot(d, aes(reorder(Feature, Importance), Importance)) + geom_col(fill = "#2a9d8f") + coord_flip() + theme_minimal(base_size = 13) + labs(x = NULL)
  })
  output$whatif <- renderText({
    f <- fit(); tr <- f$sp$train
    nd <- tr[1, f$models$predictors, drop = FALSE]
    for (p in f$models$predictors) nd[[p]] <- median(tr[[p]], na.rm = TRUE)         # defaults = typical values
    set <- function(col, v) if (col %in% names(nd)) nd[[col]] <<- v
    set("Temperature_C", input$w_temp); set("Humidity_pct", input$w_hum); set("Occupancy_pct", input$w_occ)
    set("Hour", input$w_hour); set("IsWeekend", as.integer(input$w_wend)); set("Weekday", if (input$w_wend) 6 else 3)
    paste("Predicted:", round(predict_model(f$models, "rf", nd), 1), "kWh")
  })

  # ---- savings -------------------------------------------------------
  scen <- reactive({
    d <- df(); peak <- d$Hour %in% 11:17 & d$IsWeekend == 0
    low <- if ("Occupancy_pct" %in% names(d)) d$Occupancy_pct < 20 else d$IsWeekend == 1
    d$Scenario <- d$Energy_kWh * ifelse(peak, 1 - input$s_peak / 100, ifelse(low, 1 - input$s_low / 100, 1))
    d
  })
  saved <- reactive(sum(scen()$Energy_kWh - scen()$Scenario))
  output$vb_s_kwh  <- renderValueBox(valueBox(paste(fmt(saved()), "kWh"), "Energy saved", icon = icon("bolt"), color = "green"))
  output$vb_s_cost <- renderValueBox(valueBox(paste("Rs", fmt(saved() * tariff())), "Cost saved", icon = icon("rupee-sign"), color = "blue"))
  output$vb_s_co2  <- renderValueBox(valueBox(paste(fmt(saved() * ef()), "kg"), "CO2 avoided", icon = icon("leaf"), color = "olive"))
  output$p_save <- renderPlot({
    m <- scen() %>% group_by(Month) %>% summarise(Baseline = sum(Energy_kWh), Scenario = sum(Scenario), .groups = "drop") %>%
      tidyr::pivot_longer(-Month, names_to = "Case", values_to = "kWh")
    ggplot(m, aes(factor(Month), kWh, fill = Case)) + geom_col(position = "dodge") +
      scale_fill_manual(values = c(Baseline = "#e76f51", Scenario = "#2a9d8f")) + theme_minimal(base_size = 13) + labs(x = "Month")
  })

  # ---- data ----------------------------------------------------------
  output$t_data <- renderDT(datatable(df() %>% select(-Date) %>% mutate(Timestamp = format(Timestamp)), options = list(pageLength = 10, scrollX = TRUE), rownames = FALSE))
  output$dl <- downloadHandler(filename = function() "energy_clean.csv", content = function(file) write.csv(loaded()$data, file, row.names = FALSE))
}

shinyApp(ui, server)
