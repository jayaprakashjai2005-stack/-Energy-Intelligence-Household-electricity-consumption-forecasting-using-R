# =====================================================================
# analysis.R : end-to-end pipeline (Stages 1-6) -> figures/ + results/
# Run:  Rscript analysis.R
# =====================================================================
suppressPackageStartupMessages({ library(ggplot2); library(dplyr); library(corrplot) })
source("R/energy_functions.R")
dir.create("figures", showWarnings = FALSE); dir.create("results", showWarnings = FALSE)
if (!file.exists("data/energy_data.csv")) source("generate_data.R")
theme_set(theme_minimal(base_size = 12))
save_fig <- function(name, p, w = 8, h = 4.5) ggsave(file.path("figures", name), p, width = w, height = h, dpi = 150)

# ---- Stage 1: load & inspect -----------------------------------------
loaded <- load_energy_data("data/energy_data.csv")
raw <- loaded$data
cat("Dimensions:", dim(raw), "\n"); str(raw); print(summary(raw))

# ---- Stage 2: cleaning -----------------------------------------------
cat("\n--- Cleaning log ---\n"); print(unlist(loaded$log))
energy <- add_features(raw)

# ---- Stage 3: visualization (EDA) ------------------------------------
save_fig("01_energy_distribution.png",
  ggplot(energy, aes(Energy_kWh)) + geom_histogram(bins = 50, fill = "#2a9d8f") +
    labs(title = "Distribution of hourly energy consumption", x = "Energy (kWh)", y = "Count"))

daily <- energy %>% group_by(Date) %>% summarise(kWh = sum(Energy_kWh))
save_fig("02_daily_consumption.png",
  ggplot(daily, aes(Date, kWh)) + geom_line(colour = "#264653") + geom_smooth(se = FALSE, colour = "#e76f51") +
    labs(title = "Daily energy consumption (with trend)", y = "kWh per day"))

heat <- energy %>% group_by(Weekday, Hour) %>% summarise(kWh = mean(Energy_kWh), .groups = "drop")
heat$Day <- factor(heat$Weekday, 1:7, c("Mon","Tue","Wed","Thu","Fri","Sat","Sun"))
save_fig("03_hour_weekday_heatmap.png",
  ggplot(heat, aes(Hour, Day, fill = kWh)) + geom_tile() + scale_fill_viridis_c(option = "magma") +
    labs(title = "Average load by hour and weekday", fill = "kWh"))

save_fig("04_temperature_vs_energy.png",
  ggplot(energy, aes(Temperature_C, Energy_kWh)) + geom_point(alpha = 0.15, colour = "#457b9d") +
    geom_smooth(colour = "#e63946") + labs(title = "Temperature vs energy (non-linear cooling load)"))

monthly <- energy %>% group_by(Month) %>% summarise(kWh = sum(Energy_kWh))
save_fig("05_monthly_consumption.png",
  ggplot(monthly, aes(factor(Month), kWh)) + geom_col(fill = "#f4a261") +
    labs(title = "Monthly consumption", x = "Month", y = "kWh"))

png("figures/06_correlation.png", 1200, 1000, res = 150)
num <- energy[, c("Energy_kWh", intersect(KNOWN_PREDICTORS, names(energy)), "Hour", "Weekday", "Month", "Lag24")]
corrplot(cor(num, use = "pairwise.complete.obs"), method = "color", tl.cex = 0.8, addCoef.col = "black", number.cex = 0.6)
dev.off()
write.csv(round(cor(num, use = "pairwise.complete.obs"), 3), "results/correlation_matrix.csv")

# ---- Stage 4: chronological split ------------------------------------
sp <- split_time(energy, 0.8)
cat("\nTrain rows:", nrow(sp$train), "| Test rows:", nrow(sp$test),
    "\nTrain period:", format(min(sp$train$Date)), "to", format(max(sp$train$Date)),
    "\nTest  period:", format(min(sp$test$Date)),  "to", format(max(sp$test$Date)), "\n")

# ---- Stage 5: model training & evaluation ----------------------------
preds  <- get_predictors(energy)
models <- train_models(sp$train, preds, trees = 200)
print(summary(models$lm))
res <- evaluate_all(models, sp$test); print(res)
write.csv(res, "results/model_comparison.csv", row.names = FALSE)

for (m in c("lm", "rf")) {
  d <- data.frame(Actual = sp$test$Energy_kWh, Predicted = predict_model(models, m, sp$test))
  save_fig(paste0("07_actual_vs_pred_", m, ".png"),
    ggplot(d, aes(Actual, Predicted)) + geom_point(alpha = 0.25, colour = "#1d3557") +
      geom_abline(colour = "red") + labs(title = paste("Predicted vs Actual -", c(lm = "Linear Regression", rf = "Random Forest")[m])), 6, 5)
}
imp <- sort(models$rf$variable.importance, decreasing = TRUE)
impd <- data.frame(Feature = names(imp), Importance = as.numeric(imp))
write.csv(impd, "results/feature_importance.csv", row.names = FALSE)
save_fig("08_feature_importance.png",
  ggplot(impd, aes(reorder(Feature, Importance), Importance)) + geom_col(fill = "#2a9d8f") + coord_flip() +
    labs(title = "Random Forest feature importance", x = NULL))

wk <- sp$test[1:(24 * 7), ]; wk$RF <- predict_model(models, "rf", wk)
save_fig("09_week_forecast.png",
  ggplot(wk, aes(Timestamp)) + geom_line(aes(y = Energy_kWh, colour = "Actual")) + geom_line(aes(y = RF, colour = "RF forecast")) +
    scale_colour_manual(values = c(Actual = "#264653", `RF forecast` = "#e76f51")) +
    labs(title = "One-week forecast on unseen test data", y = "kWh", colour = NULL))

# ---- Stage 6: anomaly detection + cost / carbon -----------------------
an <- detect_anomalies(energy, k = 4)
cat("\nAnomalies flagged:", sum(an$Anomaly), "of", nrow(an), "\n")
write.csv(an[an$Anomaly, c("Timestamp", "Energy_kWh", "Expected", "Z")], "results/anomalies.csv", row.names = FALSE)
save_fig("10_anomalies.png",
  ggplot(an, aes(Timestamp, Energy_kWh)) + geom_line(colour = "grey70", linewidth = 0.2) +
    geom_point(data = an[an$Anomaly, ], colour = "red", size = 1.3) +
    labs(title = "Detected consumption anomalies (robust z > 4)", y = "kWh"))

total <- sum(energy$Energy_kWh); tariff <- 8; ef <- 0.82
kpi <- data.frame(Total_kWh = round(total), Peak_hourly_kWh = max(energy$Energy_kWh),
                  Cost_INR = round(total * tariff), CO2_tonnes = round(total * ef / 1000, 1),
                  Anomalies = sum(an$Anomaly), Anomaly_excess_kWh = round(sum((an$Energy_kWh - an$Expected)[an$Anomaly])))
print(kpi); write.csv(kpi, "results/kpi_summary.csv", row.names = FALSE)

# Savings scenario: -10% load in weekday peak hours (11-17h), -15% in low-occupancy hours
peak <- energy$Hour %in% 11:17 & energy$IsWeekend == 0
low  <- energy$Occupancy_pct < 20
saved <- sum(energy$Energy_kWh[peak]) * 0.10 + sum(energy$Energy_kWh[low & !peak]) * 0.15
cat("Scenario savings: ", round(saved), "kWh | INR", round(saved * tariff), "| CO2", round(saved * ef), "kg\n")
write.csv(data.frame(Saved_kWh = round(saved), Saved_INR = round(saved * tariff), Saved_CO2_kg = round(saved * ef)),
          "results/savings_scenario.csv", row.names = FALSE)
