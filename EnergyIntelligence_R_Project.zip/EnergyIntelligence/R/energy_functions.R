# =====================================================================
# energy_functions.R : reusable functions for the Energy Intelligence project
# Used by both analysis.R (report pipeline) and app.R (Shiny dashboard)
# =====================================================================
suppressPackageStartupMessages({ library(dplyr); library(ranger); library(rpart) })

KNOWN_PREDICTORS <- c("Temperature_C", "Humidity_pct", "SolarRadiation_Wm2",
                      "WindSpeed_ms", "Occupancy_pct", "IsHoliday")

# ---- 1. Simulated smart-building dataset (hourly, 1 year) -------------
# Used when no real CSV is supplied. Physics-inspired, with noise + injected faults.
generate_energy_data <- function(seed = 108, start = "2025-01-01", days = 365) {
  set.seed(seed)
  ts   <- seq(as.POSIXct(start, tz = "UTC"), by = "hour", length.out = days * 24)
  n    <- length(ts)
  hour <- as.integer(format(ts, "%H")); doy <- as.integer(format(ts, "%j"))
  wd   <- as.integer(format(ts, "%u")); date <- as.Date(ts)
  holiday_days <- sample(unique(date[wd <= 5]), 12)
  holiday <- as.integer(date %in% holiday_days)
  weekend <- as.integer(wd >= 6)

  Temperature_C <- 28.5 + 4.5 * sin(2 * pi * (doy - 110) / 365) +
                   3.5 * sin(2 * pi * (hour - 8) / 24) + rnorm(n, 0, 1)
  Humidity_pct  <- pmin(100, pmax(30, 72 - 1.6 * (Temperature_C - 28) + rnorm(n, 0, 5)))
  cloud <- pmin(1, pmax(0, 0.35 + 0.25 * sin(2 * pi * (doy - 200) / 365) + rnorm(n, 0, 0.25)))
  SolarRadiation_Wm2 <- pmax(0, sin(pi * (hour - 6) / 12)) * (1 - 0.7 * cloud) * 950
  WindSpeed_ms  <- pmax(0, 3.5 + 1.5 * sin(2 * pi * (doy - 170) / 365) + rnorm(n, 0, 1.2))

  working  <- weekend == 0 & holiday == 0
  occ_base <- ifelse(working,
                     ifelse(hour >= 8 & hour <= 18, 85, ifelse(hour %in% c(7, 19), 35, 8)),
                     ifelse(hour >= 10 & hour <= 16, 15, 4))
  Occupancy_pct <- round(pmin(100, pmax(0, occ_base + rnorm(n, 0, 6))))

  # HVAC runs on a schedule (not purely on occupancy) -> non-linear, hour-dependent load
  hvac_on  <- ifelse(working & hour >= 7 & hour <= 19, 1, 0.25)
  cooling  <- hvac_on * pmax(Temperature_C - 25, 0)^1.5 * (1 + 0.012 * pmax(Humidity_pct - 60, 0)) * 8
  startup  <- ifelse(working & hour %in% c(6, 7), 45, 0)          # morning pre-cooling surge
  lighting <- ifelse(hour >= 6 & hour <= 21, 28, 8) * (1 - 0.5 * SolarRadiation_Wm2 / 950) *
              (0.4 + 0.006 * Occupancy_pct)
  Energy_kWh <- 70 + cooling + startup + lighting + 0.9 * Occupancy_pct + rnorm(n, 0, 9)
  spikes <- sample.int(n, round(0.004 * n))            # injected equipment faults
  Energy_kWh[spikes] <- Energy_kWh[spikes] + runif(length(spikes), 90, 200)

  data.frame(Timestamp = format(ts, "%Y-%m-%d %H:%M:%S"),
             Temperature_C = round(Temperature_C, 2), Humidity_pct = round(Humidity_pct, 1),
             SolarRadiation_Wm2 = round(SolarRadiation_Wm2, 1), WindSpeed_ms = round(WindSpeed_ms, 2),
             Occupancy_pct = Occupancy_pct, IsHoliday = holiday, Energy_kWh = round(Energy_kWh, 2))
}

# ---- 2. Load + clean --------------------------------------------------
load_energy_data <- function(path) {
  df <- read.csv(path, stringsAsFactors = FALSE)
  log <- list(rows_raw = nrow(df))
  if (!all(c("Timestamp", "Energy_kWh") %in% names(df)))
    stop("CSV must contain at least 'Timestamp' and 'Energy_kWh' columns.")
  df$Timestamp <- as.POSIXct(df$Timestamp, tz = "UTC",
    tryFormats = c("%Y-%m-%d %H:%M:%S", "%Y-%m-%d %H:%M", "%Y-%m-%dT%H:%M:%S",
                   "%d-%m-%Y %H:%M", "%d/%m/%Y %H:%M"))
  if (all(is.na(df$Timestamp))) stop("Could not parse the 'Timestamp' column.")
  log$bad_timestamps <- sum(is.na(df$Timestamp))
  df <- df[!is.na(df$Timestamp), ]
  log$duplicates <- sum(duplicated(df$Timestamp))
  df <- df[!duplicated(df$Timestamp), ]
  df <- df[order(df$Timestamp), ]
  df$Energy_kWh[!is.na(df$Energy_kWh) & df$Energy_kWh < 0] <- NA   # negative energy is invalid
  num_cols <- names(df)[sapply(df, is.numeric)]
  log$missing_filled <- sum(is.na(df[num_cols]))
  for (cl in num_cols) if (anyNA(df[[cl]]) && sum(!is.na(df[[cl]])) > 1)
    df[[cl]] <- approx(seq_along(df[[cl]]), df[[cl]], xout = seq_along(df[[cl]]), rule = 2)$y
  log$rows_clean <- nrow(df)
  list(data = df, log = log)
}

# ---- 3. Feature engineering ------------------------------------------
add_features <- function(df) {
  df <- df[order(df$Timestamp), ]
  df$Date      <- as.Date(df$Timestamp)
  df$Hour      <- as.integer(format(df$Timestamp, "%H"))
  df$Weekday   <- as.integer(format(df$Timestamp, "%u"))     # 1 = Mon ... 7 = Sun
  df$Month     <- as.integer(format(df$Timestamp, "%m"))
  df$IsWeekend <- as.integer(df$Weekday >= 6)
  df$Lag24     <- dplyr::lag(df$Energy_kWh, 24)               # same hour, previous day
  df
}
get_predictors <- function(df)
  c(intersect(KNOWN_PREDICTORS, names(df)), "Hour", "Weekday", "Month", "IsWeekend", "Lag24")

# ---- 4. Modelling -----------------------------------------------------
split_time <- function(df, p = 0.8) {              # chronological split (no leakage from future)
  df <- df[!is.na(df$Lag24), ]
  k <- floor(nrow(df) * p)
  list(train = df[seq_len(k), ], test = df[(k + 1):nrow(df), ])
}
train_models <- function(train, predictors, trees = 200) {
  f <- reformulate(predictors, "Energy_kWh")
  list(formula = f, predictors = predictors,
       lm = lm(f, data = train),
       dt = rpart(f, data = train, control = rpart.control(cp = 0.001, maxdepth = 10)),
       rf = ranger(f, data = train, num.trees = trees, mtry = max(2, floor(length(predictors) / 2)),
                  importance = "impurity", seed = 108))
}
predict_model <- function(models, name, newdata) {
  switch(name,
    lm = as.numeric(predict(models$lm, newdata)),
    dt = as.numeric(predict(models$dt, newdata)),
    rf = predict(models$rf, data = newdata)$predictions)
}
calc_metrics <- function(actual, pred) {
  sse <- sum((actual - pred)^2); sst <- sum((actual - mean(actual))^2)
  data.frame(RMSE = sqrt(mean((actual - pred)^2)), MAE = mean(abs(actual - pred)),
             R2 = 1 - sse / sst, MAPE_pct = 100 * mean(abs((actual - pred) / actual)))
}
evaluate_all <- function(models, test) {
  nm <- c(lm = "Linear Regression", dt = "Decision Tree", rf = "Random Forest")
  do.call(rbind, lapply(names(nm), function(m)
    cbind(Model = nm[[m]], round(calc_metrics(test$Energy_kWh, predict_model(models, m, test)), 4))))
}

# ---- 5. Anomaly detection --------------------------------------------
# Expected load = Random Forest out-of-bag prediction (what the building SHOULD use given
# weather, occupancy and time). Robust z-score of the residual (median/MAD); flag z > k.
fit_expected <- function(df, trees = 100) {
  preds <- setdiff(get_predictors(df), "Lag24")
  rf <- ranger(reformulate(preds, "Energy_kWh"), data = df, num.trees = trees, seed = 108)
  df$Expected <- rf$predictions                       # OOB predictions: not fitted on that row
  df$Resid    <- df$Energy_kWh - df$Expected
  df$Z        <- df$Resid / (1.4826 * mad(df$Resid))
  df
}
flag_anomalies <- function(df, k = 4) { df$Anomaly <- df$Z > k; df }
detect_anomalies <- function(df, k = 4) flag_anomalies(fit_expected(df), k)
